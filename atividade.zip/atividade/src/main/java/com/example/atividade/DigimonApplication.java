package com.example.atividade;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DigimonApplication {

	public static void main(String[] args) {
		SpringApplication.run(DigimonApplication.class, args);
	}

}
